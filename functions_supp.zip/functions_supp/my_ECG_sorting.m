function [parameter,mat_ind_proj_sel] = my_ECG_sorting(parameter,ECG)
shift_zone = 0;

% Remove respiratory component
ecg_sm = sum(ECG,2);
sigma = 0.32 ; % respiratory filter
% double Fs if the frequency sampling is 1/TR
if size(ecg_sm,1) == size(parameter.angle_proj,2)
    Fs2 = parameter.Fs.*2;
else
    Fs2 = parameter.Fs;
end
[Resp_comp] = Quantitative_frequency_filter(ecg_sm,Fs2,sigma);
ecg_sm = ecg_sm-Resp_comp;

sel = (max(ecg_sm)-min(ecg_sm))/16;
[peakLoc,peakMagn] = peakfinder(ecg_sm,sel); % deriv_ecg

% if display ==1
%     figure()
%     hold on
%     plot(ecg_sm(:,1),'b')
%     plot(ECG,'g')
%     plot(peakLoc,peakMagn,'*r')
% end
peakLoc_orig = peakLoc;


%% Check the peak detection an fix non detection
peak_period = diff(peakLoc);
peak_period_outliers = isoutlier(peak_period,'grubbs');
median_peak_period = median(peak_period);
quantile_peak_period = quantile(peak_period,0.75);


counter_error = 0;
for ind = 1:size(peak_period,1)
    if peak_period_outliers(ind,1) ==1
        if peak_period(ind,1) >1.6*median_peak_period && peak_period(ind,1) <2.8*median_peak_period
            counter_error = counter_error+1;
            peakLoc = cat(1,peakLoc(1:ind+counter_error-1),round(mean([peakLoc(ind+counter_error-1,1) peakLoc(ind+counter_error,1)])),peakLoc(ind+counter_error:end));
        end
        if peak_period(ind,1) >2.8*median_peak_period && peak_period(ind,1) <3.8*median_peak_period
            counter_error = counter_error+2;
            peakLoc = cat(1,peakLoc(1:ind+counter_error-2),round(peakLoc(ind+counter_error-2,1) + (peakLoc(ind+counter_error-1,1)-peakLoc(ind+counter_error-2,1))/3),round(peakLoc(ind+counter_error-2,1) + (peakLoc(ind+counter_error-1,1)-peakLoc(ind+counter_error-2,1))/3*2),peakLoc(ind+counter_error-1:end));
        end
        if peak_period(ind,1) >3.8*median_peak_period && peak_period(ind,1) <4.8*median_peak_period
            counter_error = counter_error+3;
            peakLoc = cat(1,peakLoc(1:ind+counter_error-3),round(peakLoc(ind+counter_error-3,1) + (peakLoc(ind+counter_error-2,1)-peakLoc(ind+counter_error-3,1))/4),round(peakLoc(ind+counter_error-3,1) + (peakLoc(ind+counter_error-2,1)-peakLoc(ind+counter_error-3,1))/4*2),round(peakLoc(ind+counter_error-3,1) + (peakLoc(ind+counter_error-2,1)-peakLoc(ind+counter_error-3,1))/4*3),peakLoc(ind+counter_error-2:end));
        end
    end
end

if parameter.display ==1
    supp_loc = setdiff(peakLoc,peakLoc_orig);
    figure()
    hold on
    plot(ecg_sm,'b')
    plot(peakLoc_orig,peakMagn,'*r')
    plot(supp_loc,ecg_sm(supp_loc),'*r','MarkerSize',15)
end

clearvars counter_error peak_period mean_period peak_period_outliers;


%% Cut the matrice by periode ecg
peakLoc = peakLoc+shift_zone; % manual adjustement
mat_ecg = zeros(max(diff(peakLoc)),size(peakLoc,1)-1);
mat_ind_ecg = zeros(max(diff(peakLoc)),size(peakLoc,1)-1);
mat_ind_ecg_disp = zeros(max(diff(peakLoc)),size(peakLoc,1)-1);
ind_ecg = (1:size(ecg_sm,1))';

for ind = 1:size(peakLoc,1)-1
    Npoints = peakLoc(ind+1)-peakLoc(ind);
    mat_ecg(1:Npoints,ind) = ecg_sm(peakLoc(ind):peakLoc(ind+1)-1,:);
    mat_ind_ecg(1:Npoints,ind) = ind_ecg(peakLoc(ind):peakLoc(ind+1)-1,:);
end

for card_ind = 1:parameter.N_card_phase
    ind_card_phase1 = round(((quantile_peak_period/parameter.N_card_phase)*(card_ind-1))+1);
    ind_card_phase2 = round(((quantile_peak_period/parameter.N_card_phase)*(card_ind))+1);
    ind_card_phase2 = min([ind_card_phase2 size(mat_ind_ecg,1)]);
    if card_ind ==parameter.N_card_phase
        ind_card_phase2 = size(mat_ind_ecg,1);
    end
    proj_sel_card_tmp =mat_ind_ecg(ind_card_phase1:ind_card_phase2,:);
    proj_sel_card_tmp = proj_sel_card_tmp(:);
    proj_sel_card_tmp = proj_sel_card_tmp(proj_sel_card_tmp~=0);
    mat_ind_proj_sel{:,card_ind} = proj_sel_card_tmp;
end


