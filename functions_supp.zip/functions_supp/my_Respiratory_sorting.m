function [parameter,proj_list_phase] = my_Respiratory_sorting(parameter,Resp_signal)

offset = 100; % offset allowing to not use the first projections
    Resp_signal = sum(Resp_signal,2);

sigma = 0.32 ; % respiratory filter
% double Fs if the frequency sampling is 1/TR
if size(Resp_signal,1) == size(parameter.angle_proj,2)
    Fs2 = parameter.Fs.*2;
else
    Fs2 = parameter.Fs;
end
[Resp_only] = Quantitative_frequency_filter(Resp_signal,Fs2,sigma);

    Resp_only_calib = Resp_only(offset+1:offset+parameter.Calibration,:);

    % Cut resp period
    [peakLocResp,peakMagnResp] = peakfinder(Resp_only_calib);
    if parameter.display ==1
        figure()
        hold on
        plot(Resp_only_calib,'b')
        plot(peakLocResp,peakMagnResp,'*r')
        hold off
    end
    
    mat_Resp = zeros(max(diff(peakLocResp)),size(peakLocResp,1)-1);
    mat_ind_Resp = zeros(max(diff(peakLocResp)),size(peakLocResp,1)-1);
    mat_ind_Resp_disp = zeros(max(diff(peakLocResp)),size(peakLocResp,1)-1);
    ind_Resp = (1:size(Resp_only_calib,1))';
    
    for ind = 1:size(peakLocResp,1)-1
        Npoints = peakLocResp(ind+1)-peakLocResp(ind);
        mat_Resp(1:Npoints,ind) = Resp_only_calib(peakLocResp(ind):peakLocResp(ind+1)-1,:);
        mat_ind_Resp(1:Npoints,ind) = ind_Resp(peakLocResp(ind):peakLocResp(ind+1)-1,:);
        mat_ind_Resp_disp(1:Npoints,ind) = (1:peakLocResp(ind+1)-peakLocResp(ind))';
    end
    
    
    Npoint_phase = floor(size(mat_ind_Resp,1)/parameter.N_resp_phase);
    proj_list_phase = zeros(Npoint_phase*size(mat_ind_Resp,2),parameter.N_resp_phase);
    for resp_phase = 1:parameter.N_resp_phase
        proj_list_phase_tmp = mat_ind_Resp(Npoint_phase*(resp_phase-1)+1:Npoint_phase*(resp_phase),:);
        proj_list_phase(:,resp_phase) = proj_list_phase_tmp(:);
    end