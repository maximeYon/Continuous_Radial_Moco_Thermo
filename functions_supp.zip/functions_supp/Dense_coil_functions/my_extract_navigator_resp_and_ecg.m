function [ navigator ] = my_extract_navigator_resp_and_ecg( data_resp , data_ecg  , TR)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

% data is a 2D matrix with center points of projection in dimension 1 and
% coils in dimension number 2

%%OPTIONS
Fs = 1/(TR/1000); % in Hz
threshold.resp=1.00;
threshold.ecg=1; % 1
threshold.svd=0.15; % 0.15
debug='N';

    
    %% SELFGATING
    
    debut =1;
    fin =size(data_resp,1);
    offset=0;
    condition=1;
    
    while (condition<=1)
        
        
        [ matrixC, matrixG, ~ ] = extract_correlation( data_resp, threshold.resp-offset,  debug );
        
        [ matrixU ] = extract_UU( matrixG , debug);
        
        [ navigator.resp.raw , coilID] = extract_cluster_clean( matrixU, matrixC, data_resp , threshold.svd );
        
        condition=sum(coilID);
        
%         str_msg=sprintf('%d %2.3f\n', condition , threshold.resp-offset); disp(str_msg);
        
        offset=offset+0.03;
        
    end
    
    
    offset=0;
    condition=1;
    
    while (condition<=1)
        
        [ matrixC, matrixG, ~] = extract_correlation( data_ecg , threshold.ecg-offset, debug );
        
        [ matrixU ] = extract_UU( matrixG , debug);
        
        [ navigator.ecg.raw , coilID] = extract_cluster_clean( matrixU, matrixC, data_ecg , threshold.svd );
        
        condition=sum(coilID);
        
%         str_msg=sprintf('%d %2.3f\n', condition , threshold.ecg-offset); disp(str_msg);
        
        offset=offset+0.03;
        
    end
    
    %% nous avons extrait les deux navigateurs neanmoins il reste quelques étapes de traitement à effectuer
    
    %% partie respiration
    
    [ navigator.resp.nodrift ] = remove_drift_respiration( navigator.resp.raw, debut, fin );
    
    [ navigator.resp.normalize ] = normalize_navigator( navigator.resp.nodrift, debut, fin );
    
    %% partie ecg
    
%     [navigator.ecg.filter]=apply_butterworth_filtering(navigator.ecg.raw,3, Fs);
    
end



