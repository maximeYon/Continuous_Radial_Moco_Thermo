cas = 1

addpath('Dense_coil_functions/');
addpath('Plot_functions/');

kspace= Data{cas}.vecteur_for_central_point;

clear vecteur_for_central_point_to_save
point_central=squeeze(kspace((readout/2)+1,:,:)); %129 in other cases when matrix 256
%190 with a matrix of 384  384+1
figure()
for c = 3:size(point_central,2) % les deux premières antennes sont les micro coils dans cette série
    subplot(6,6,c-2)
    plot(point_central(:,c))
    str = sprintf('antenne %d', c);
    title(str)
end

number_of_segments= Data{cas}.segment;


Tr_effectif=(Data{cas}.hdr.sequenceParameters.TR/Data{cas}.segment)/1000; %en ms en moyenne 1 projections toutes les 23.3ms
Tr_effectif_global=(Data{cas}.hdr.sequenceParameters.TR)/1000; % en ms 3 projetcions toutes les 70ms (Tracking compris dedans)
f_sampled=1/(Tr_effectif_global); % en Hz Frequence à laquelle les projections sont acquises

%% On filtre les signaux pour extraire la resp  c'est à dire on enleve les ahutes fréquences

fc_resp = 0.2; % 12resp/min ==> 0.2Hz FREQUENCE DE COUPURE POUR BUTTERWORTH

% [projection, channels]
number_of_projections=size(point_central,1);
number_of_channels=size(point_central,2);


data.allrep.original=point_central;

for c=1:number_of_channels
    data.allrep.raw(:,c)=data.allrep.original(:,c)-mean(data.allrep.original(:,c),1);
end


[b,a] = butter(2,fc_resp/(f_sampled/2),'low');
data.allrep.filter.resp=filter(b,a,data.allrep.raw);


figure()
for c = 3:size(point_central,2) % les deux premières antennes sont les micro coils dans cette série
    subplot(6,6,c-2)
    plot( data.allrep.raw(:,c),'b')
    hold on
    plot(data.allrep.filter.resp(:,c),'r')
    str = sprintf('antenne %d', c);
    title(str)
end

%% SOUSTRACTION DE LA RESP
data.allrep.substract.resp=zeros(size(data.allrep.raw));

for c=1:number_of_channels
    data.allrep.substract.resp(:,c)=data.allrep.raw(:,c)-data.allrep.filter.resp(:,c);
end

figure()
for c = 3:size(point_central,2)
subplot(6,6,c-2)
plot(data.allrep.substract.resp(:,c),'b')
hold on; 
str = sprintf('antenne %d', c);
title(str)
end

%% EXTRACTION ECG
fc_ecg = 1.6; % 100BPM ==> 1.6Hz FREQUENCE DE COUPURE POUR BUTTERWORTH
[b,a] = butter(2,[0.3/(f_sampled/2),5/(f_sampled/2)],'bandpass');
data.allrep.filter.ecg=filter(b,a,data.allrep.substract.resp);

% figure()
% for c = 3:3%size(point_central,2)
% subplot(6,6,c-2)
% plot(data.allrep.filter.ecg(:,c),'b')
% hold on; 
% str = sprintf('antenne %d', c);
% title(str)
% end



figure()
plot(data.allrep.filter.ecg(:,35),'b')
