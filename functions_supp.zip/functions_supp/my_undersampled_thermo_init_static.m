function [parameter,acqp,L] = my_undersampled_thermo_init_static(parameter,acqp,trajtotale,Kspace_proj)

parameter.Nxorig = parameter.Nx;
parameter.Nyorig = parameter.Ny;
parameter.Nx =parameter.Npixel;
parameter.Ny = parameter.Npixel;

%% prepare needed variables and assign them to Pr. Grissom variable names
% Constant parameters
alpha=0.0094;
gamma=42.58;
B0 =1.5;
TE =parameter.TE*10^-3;
parameter.ct =-1/(gamma*alpha*B0*TE*2*pi); % degrees C/radian
acqp.fov = parameter.FOVx; % FoV

%% creation of the mask
acqp.mask = mask_Grissom(parameter.Nx,parameter.Ny,size(Kspace_proj,1));
%     acqp.mask = mask_Grissom_cutted(parameter.Nx,parameter.Ny,size(Kspace_proj,1));

%% Define the projections and trajectory number which will be used for calibration, full sampling and undersampling thermometry
%% Calibration : acqp.L
offset = 100;

%% Checking of the librairy L
% Calibration dataset acqp.L is in image space obtained with conjugate gradient transform
img_calib = zeros(size(acqp.mask,1),size(acqp.mask,2),parameter.number_of_channels,parameter.im_cal);

%%  create library linearly
Proj_calibration_tot = Kspace_proj(:,offset+1:offset+parameter.Calibration,:); % projections used for calibration
% adapt the trajectory due to oversampling removal : /2
traj_calib_tot=trajtotale(:,offset+1:offset+parameter.Calibration,1:2)./2;           % trajectory of selected projections
traj_calib_tot = reshape(traj_calib_tot,size(traj_calib_tot,1)*size(traj_calib_tot,2),2);
traj_calib_tot = traj_calib_tot./(acqp.fov/size(Kspace_proj,1));

dcfCalib_tot = repmat(abs(traj_calib_tot(:,1)+1i*traj_calib_tot(:,2)),[1 parameter.number_of_channels]);
dcfCalib_tot = dcfCalib_tot./max(abs(dcfCalib_tot(:)));
dcfCalib_tot = single(dcfCalib_tot);

readout = size(Proj_calibration_tot,1);
traj_calib_mat=reshape(traj_calib_tot,[readout size(traj_calib_tot,1)./readout size(traj_calib_tot,2)]);
dcfCalib_mat=reshape(dcfCalib_tot,[readout size(dcfCalib_tot,1)./readout size(dcfCalib_tot,2)]);



for ind_im_cal = 1:parameter.im_cal
        start = floor(parameter.Calibration/parameter.im_cal)*(ind_im_cal-1);
        proj_list_phase_withoutZeros = start+1:start+round(parameter.Calibration/parameter.im_cal);
        
        parameter.Nspoke_lib(1,ind_im_cal) = size(proj_list_phase_withoutZeros,2);
        
            traj_calib = squeeze(traj_calib_mat(:,proj_list_phase_withoutZeros,:));
            traj_calib = reshape(traj_calib,[size(traj_calib,1)*size(traj_calib,2) size(traj_calib,3)]);
            Proj_calibration=Proj_calibration_tot(:,proj_list_phase_withoutZeros,:);
            dcfCalib = squeeze(dcfCalib_mat(:,proj_list_phase_withoutZeros,:));
            dcfCalib = reshape(dcfCalib,[size(dcfCalib,1)*size(dcfCalib,2) size(dcfCalib,3)]);
            
            Gcalib = Gmri(traj_calib,acqp.mask,'fov',acqp.fov,'basis',{'dirac'});
            Ltmp  =reshape(Proj_calibration, size(Proj_calibration,1)*size(Proj_calibration,2),size(Proj_calibration,3),1);
            for ch = 1:parameter.number_of_channels
                [xS,~] = qpwls_pcg(zeros(sum(acqp.mask(:)),1),Gcalib,diag_sp(dcfCalib(:,1)),Ltmp(:,ch),0,0,1,3,acqp.mask);
                img_calib(:,:,ch,ind_im_cal) = embed(xS(:,end),acqp.mask);
            end
end

%% 

maskTmp = repmat(acqp.mask,1,1,parameter.number_of_channels);

for imCall = 1:size(img_calib,4)
    img_calib_tmp = single(squeeze(img_calib(:,:,:,imCall)));
    L(:,imCall) = img_calib_tmp(maskTmp);
end