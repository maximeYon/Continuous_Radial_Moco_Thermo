function [ccm_Inati] = my_Reco_Inati_ccm(image, kernel, power)

%Recombine les images issues des différentes antennes en utilisant la méthode de Inati
%
%image[x, y, nbCoils, nbVolumes]
%smoothing la taille du bloc(carré) de smoothing (par défaut 5))


% kernel = 5;
% power = 1;
nbCoils = size(image, 3); % mod Max
nbVolumes = size(image, 4);

matcov = eye(nbCoils); % mod Max



% 1 - Création de la carte de sensibilité pour notre problème :

csm_Inati = coil_map_study_2d_Inati(image(:,:,:,1), kernel, power);


% Etudier l'influence du paramètre de lissage sur les images finales


% 2 - Création de la carte de recombinaison à partir de la carte de
% sensibilité et de la matrice de covariance du bruit.

%matcov2 = pinv(matcov); %La fonction ismrm_compute_ccm utilise l'inverse de la matrice de covariance, or nous, 
%nous disposons de la matrice. Il faut donc l'inverser.

ccm_Inati = ismrm_compute_ccm(csm_Inati, matcov);


