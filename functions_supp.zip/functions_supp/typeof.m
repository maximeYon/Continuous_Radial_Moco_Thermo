function ty = typeof(var)
%TYPEOF return the underlying data-type for a variable
%   TYPEOF(VAR) is the same as CLASS(VAR) for standard MATLAB data-types
%   (double, single, etc.) and the same as CLASSUNDERLYING(VAR) for custom
%   types that support underlying data.
%
%   Example:
%   typeof( single(1) ) => 'single'
%   typeof( gpuArray(single(2)) ) => 'single'

%   Copyright 2015-2017 The MathWorks, Inc.

% The functions isobject/class are very fast, so that host performance are
% not affected. Use try/catch to avoid using ismethod (on the object) which
% is quite slow. 
if isobject(var)
    try
        ty = classUnderlying(var);
    catch
        ty = class(var);
    end
else
    ty = class(var);
end
