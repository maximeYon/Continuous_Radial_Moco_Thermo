function [] = DynamicDisplay_single_im(im2D,names_exp,varargin)

struct_points = struct;
max_time_points = 0;
for ind = 1:size(varargin,2)
    max_time_points = max([max_time_points,size(varargin{1,ind},3)]);
end

figure()
subplot(1,3,1)
imagesc(abs(im2D));
colormap gray
point_obj = impoint;
[coord_point] = getPosition(point_obj);
coord_past = [0,0];
names_exp_disp = names_exp;
if exist('coord_point','var') ==1
    t0 = clock;
    while etime(clock, t0) < 300
        [coord_point] = getPosition(point_obj);
        for ind = 1:size(varargin,2)
            struct_points.(['vect_' num2str(ind)]) = squeeze(varargin{1,ind}(round(coord_point(1,2)),round(coord_point(1,1)),:));
            struct_points.(['time_' num2str(ind)]) = 0:max_time_points/(size(struct_points.(['vect_' num2str(ind)]),1)-1):max_time_points;
            struct_points.(['std_' num2str(ind)]) = std(struct_points.(['vect_' num2str(ind)]));
        end
        subplot(1,3,2:3)
        cla
                 hold on
                 for ind = 1:size(varargin,2)
                             plot(struct_points.(['time_' num2str(ind)]),struct_points.(['vect_' num2str(ind)]))
                 end
%                 ylim([0 80]);
                 ylabel('Temperature C');
                 xlabel('Image number');
                 legend(names_exp);
                 hold off
        drawnow
        pause(1)
    end
end

