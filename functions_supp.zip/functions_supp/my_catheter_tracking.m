function [parameter,Centroid,Z_intensity] = my_catheter_tracking(parameter,kspace_cath)

%% get Ablation catheter coils
ind_sel = 0;
for ind = 1:size(parameter.cath_coil,2)
    coil_name = parameter.cath_coil{ind};
    if strcmp(coil_name(end-1),'A')==1
        ind_sel = ind_sel+1;
       Selected_coils(1,ind_sel) = ind;
    end
end
cath_profile = abs(squeeze(FFTKSpace2XSpace(kspace_cath,1)));
cath_profile = cath_profile(:,Selected_coils,:);
cath_profile = smoothdata(cath_profile,'gaussian',10);
Z_intensity = max(abs(cath_profile));
cath_profile = abs(cath_profile) ./ repmat(Z_intensity,size(cath_profile,1),1,1);

clearvars Cath_SNR Cath_SNRdata Selected_coils ind_sel ind;

%% Clean profile manually
x = 1:size(cath_profile,1);
for dim_2 = 1:size(cath_profile,2)
    for dim_3 = 1:size(cath_profile,3)
        cath_prof_tmp = squeeze(cath_profile(:,dim_2,dim_3));
        cath_fit = csaps(x,cath_prof_tmp,10^-6);       
        corr = (fnval(cath_fit,x))';
        cath_prof_tmp = cath_prof_tmp-corr;
        cath_prof_tmp(cath_prof_tmp<0) = 0;
        cath_profile(:,dim_2,dim_3) = cath_prof_tmp;
    end
end
sum_cath_profile = sum(cath_profile,3);
[~,cath_profil_center] = min(abs(cumsum(sum_cath_profile)-mean(cumsum(sum_cath_profile))));
cath_profile(1:cath_profil_center(1,1)-30,1,:) = zeros(cath_profil_center(1,1)-30,1,20000);cath_profile(cath_profil_center(1,1)+30:end,1,:) = zeros(size(cath_profile,1)-(cath_profil_center(1,1)+30)+1,1,20000);
cath_profile(1:cath_profil_center(1,2)-30,2,:) = zeros(cath_profil_center(1,2)-30,1,20000);cath_profile(cath_profil_center(1,2)+30:end,2,:) = zeros(size(cath_profile,1)-(cath_profil_center(1,2)+30)+1,1,20000);

%% perform 2D reconstruction of the catheter motion
Centroid = zeros(floor(size(cath_profile,3)/2),2,size(cath_profile,2));

for coil = 1:size(cath_profile,2)
    %                             figure()
    %                             set(gcf,'color','w');
    for ind = 1:floor(size(cath_profile,3)/2)
        cath_prof = squeeze(cath_profile(:,coil,1+((ind-1)*2):(ind*2)));
        cath_angle = parameter.angle_proj(1,1+((ind-1)*2):(ind*2));
            cath_2D =iradon(cath_prof,cath_angle,'linear','Hann',size(cath_prof,1));
        
        %                         x = 0:parameter.FOVx/(size(cath_2D,1)-1):parameter.FOVx;
        %                         imagesc(x,x,cath_2D)
        %                         colormap jet
        %                         xlabel('FoV in mm')
        %                         ylabel('FoV in mm')
        %                         axis image
        %                         drawnow
        %                         pause()
        
        cath_2D(cath_2D<(0.92*max(cath_2D(:))))=0;
        stat = regionprops(logical(cath_2D),'centroid');
        
        for ctr = 1:size(stat)
            Centroid_tmp(ctr,:) = stat(ctr).Centroid;
            Centroid(ind,:,coil) = nanmean(Centroid_tmp,1);
            Centroid_tmp = nan(10,2);
        end
        %                                          pause(0.05)
    end
end

%% remove depency to projection angle
% remove spikes
% Centroid_outliers = isoutlier(Centroid,'grubbs');
Centroid = filloutliers(Centroid,'linear','grubbs');

angle_disp = parameter.angle_proj(1,2:2:end);
if parameter.display ==1
    figure()
    set(gcf,'color','w');
    color_code =[1 0 0; 0 0 1];
    ind_subplot = 0;
end
for dim2 = 1:size(Centroid,2)
    for dim3 = 1:size(Centroid,3)
            if parameter.display ==1
        ind_subplot = ind_subplot +1;
        subplot(2,2,ind_subplot)
            end
        angle_disp_cyclic = [angle_disp angle_disp-360 angle_disp+360];
        Y_cyclic = [squeeze(Centroid(:,dim2,dim3));squeeze(Centroid(:,dim2,dim3));squeeze(Centroid(:,dim2,dim3))];
        csaps_fit = csaps(angle_disp_cyclic,Y_cyclic,10^-7);
        %         csaps_fit = csaps(angle_disp,squeeze(Centroid(:,dim2,dim3)),10^-7);
        % display
        if parameter.display ==1
            hold on
            %             plot(angle_disp,Centroid(:,dim2,dim3),'.','color',color_code(dim3,:))
            plot(angle_disp,Centroid(:,dim2,dim3),'.b')
            fnplt(csaps_fit,'r')
            xlim([0 360])
            xlabel('First projection angle (degree)')
            if dim2 == 1
                ylabel('Spot position along X (pixel)')
            end
            if dim2 == 2
                ylabel('Spot position along Y (pixel)')
            end
            hold off
        end
        % display
        correction = (fnval(csaps_fit,angle_disp))';
        Centroid(:,dim2,dim3) = squeeze(Centroid(:,dim2,dim3))-(correction-mean(correction));
    end
end
if parameter.display ==1
    drawnow;
end
%% end of remove depency to projection angle

%% Micro coil selection
parameter.pixel_size = parameter.FOVx/size(cath_2D,1);

%% Get the catheter coil order
proximal = parameter.cath_coil{1,1};
proximal = proximal(1,end);
if strcmp(proximal,'p')==1
    %     figure()
    %     subplot(1,2,1)
    %     hold on
    %     plot(Centroid(:,1,1),'b')
    %     plot(Centroid(:,1,2),'r')
    %     legend('proximal','distal')
    %     subplot(1,2,2)
    %     hold on
    %     plot(Centroid(:,2,1),'b')
    %     plot(Centroid(:,2,2),'r')
    %     legend('proximal','distal')
    
    %     Centroid (proj,XY,ProximalDistal)
    if parameter.micro_coil_selection ==1
        Centroid=mean(Centroid,3)-(Centroid(:,:,2)-Centroid(:,:,1));
    end
    if parameter.micro_coil_selection ==2
        Centroid=Centroid(:,:,1);
    end
    if parameter.micro_coil_selection ==3
        Centroid=Centroid(:,:,2);
    end
    tip_position = mean(mean(Centroid,3)-((Centroid(:,:,2)-Centroid(:,:,1).*1)),1);
else
    if parameter.micro_coil_selection ==1
        Centroid=mean(Centroid,3)-(Centroid(:,:,1)-Centroid(:,:,2));
    end
    if parameter.micro_coil_selection ==2
        Centroid=Centroid(:,:,2);
    end
    if parameter.micro_coil_selection ==3
        Centroid=Centroid(:,:,2);
    end
    tip_position = mean(Centroid,3)-(Centroid(:,:,2)-Centroid(:,:,1));
end

if parameter.micro_coil_selection ==4
    Centroid = mean(Centroid,3); % average the coils
end

Z_intensity = squeeze(Z_intensity)';

clearvars Centroid_tmp ctr stat cath_2D cath_angle cath_prof ind coil cath_profile;
clearvars ax1 ax2 ax3;
