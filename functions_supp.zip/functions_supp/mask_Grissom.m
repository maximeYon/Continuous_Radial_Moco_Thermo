function [mask] = mask_Grissom(Nx,Ny,readout)


[I,J] = ndgrid(1:Nx,1:Ny);
ic = Nx/2+1; jc = ic; r = Nx/2;
M = double((I-ic).^2+(J-jc).^2<=r^2); 
M(1,:) = zeros(1,size(M,2)); M(:,1) = zeros(size(M,1),1);

mask = logical(M);
unit = ones(size(mask));
num_points = size(unit(mask(:)),1)/readout;
num_points_round = floor(num_points);

dy = repmat((-size(mask,1)/2:size(mask,1)/2-1)',1,size(mask,2));dx = dy';
d_mat = sqrt(dx.^2+dy.^2);
d_mat(mask==0) = NaN;
mask = double(mask);

if num_points_round<num_points
    nb_point_trop = (num_points-num_points_round)*readout;
    [val_sorted,~]=sort(d_mat(:));
    val_sorted = val_sorted(isnan(val_sorted)==0);
    for point = 1:nb_point_trop
        [Xtrop,Ytrop] = find(d_mat == val_sorted(end-point+1,1),1,'last');
        mask(Xtrop,Ytrop)=0;
        d_mat(Xtrop,Ytrop)=0;
    end     
end

mask = logical(mask);