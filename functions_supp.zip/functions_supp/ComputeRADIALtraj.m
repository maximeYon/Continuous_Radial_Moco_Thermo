function [ k,w,angles ] = ComputeRADIALtraj( N,nFE,osf,GA)


sizeR2=N*osf;
kx = linspace(-.5,.5,sizeR2);
ky = linspace(-.5,.5,sizeR2);
k = zeros(nFE*numel(kx),2);
w = zeros(size(k,1),1);

angles = zeros(1,nFE);

for p=1:nFE,
    if GA==1
        if(p==1)
            alpha=pi/2;
        else
            alpha=mod(alpha+pi*(sqrt(5)-1)/2,pi);
        end
    elseif GA==2
       if(p==1)
            alpha=pi/2;
        else
            alpha=alpha+pi/((sqrt(5)+1)*0.5) ;
        end
   else
      alpha = p*pi/(nFE);
   end
    angles(1,p) = alpha;
    k((p-1)*numel(kx)+(1:numel(kx)),1) = kx'*cos(alpha);
    k((p-1)*numel(kx)+(1:numel(kx)),2) = kx'*sin(alpha);
    k((p-1)*numel(kx)+(1:numel(kx)),3)=0;
    w((p-1)*numel(kx)+(1:numel(kx))) = abs(kx);
end


w = w .* (numel(w/sum(w(:))));
% plot(k(:,1),k(:,2),'.');


end

