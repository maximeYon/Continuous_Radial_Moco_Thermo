
function [kspace_CC] = coil_compression_radial(kspace,threshold)

% method can be : 'Walsh', 'Parker', 'Tsao', 'Inati'

%% PCA et compression d'antennes
% Création de la matrice à utiliser pour la pca.
% Dans un souci de rapidité, nous utiliserons 64 projections
number_of_projections = min(64,size(kspace,2));

data_for_pca = kspace(1,1:number_of_projections);
first_readout=data_for_pca{1};
readout=size(first_readout,1);
number_of_channels= size(first_readout,2);
clearvars first_readout;
matrice_for_pca=zeros(readout, number_of_projections,number_of_channels );

for p=1:number_of_projections
matrice_for_pca(:,p,:) = data_for_pca{p};
end

data_for_pca = reshape(matrice_for_pca,size(matrice_for_pca,1)*size(matrice_for_pca,2),size(matrice_for_pca,3));

%Calcul de la moyenne et soustraction
mean_data_for_pca = sum(data_for_pca, 1) ./  size(data_for_pca, 1);
data_for_pca = data_for_pca - repmat(mean_data_for_pca, size(data_for_pca,1),1);
clearvars mean_data_for_pca

%% PCA
[coeffPCA, ~, latent] = pca(data_for_pca);
nb_coils_reduc = sum((latent>threshold*max(latent))); %%Contains 1 if the i-th coil's coeff is greater than 1/50 of the first o
         
%% Application des coeffs
matrice_kspace = complex(zeros(readout,size(kspace,2),number_of_channels),zeros(readout,size(kspace,2),number_of_channels));     
for p=1:size(kspace,2)
matrice_kspace(:,p,:) = kspace{p};
end

matrice_kspace_lin =reshape(matrice_kspace,size(matrice_kspace,1)*size(matrice_kspace,2),size(matrice_kspace,3));                      
matrice_kspace_lin = matrice_kspace_lin * coeffPCA;
matrice_kspace = reshape(matrice_kspace_lin,size(matrice_kspace,1),size(matrice_kspace,2),size(matrice_kspace,3));

matrice_kspace = permute(matrice_kspace,[1 3 2]);
matrice_kspace = matrice_kspace(:,1:nb_coils_reduc,:);
kspace_CC = permute(squeeze(mat2cell(matrice_kspace,readout,nb_coils_reduc, ones(size(matrice_kspace,3),1))),[2 1]);



        



    

