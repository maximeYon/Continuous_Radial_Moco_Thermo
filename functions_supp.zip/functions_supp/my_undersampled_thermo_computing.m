function [parameter,Temp_Grissom] = my_undersampled_thermo_computing(parameter,acqp,algp,L,Kspace_proj,trajtotale)

% adapt the trajectory due to oversampling removal : /2
trajtotale = trajtotale./2;
%% Loop of Thermometry code
% create bucket of the dataset to allow paralele computing

bucket = struct;
for image_number = 1:floor(size(Kspace_proj,2)/parameter.Nspokes)
    bucket(image_number).acqp = acqp;
    Proj_thermo = Kspace_proj(:,parameter.Nspokes*(image_number-1)+1:parameter.Nspokes*(image_number),:);
    bucket(image_number).acqp.data = reshape(Proj_thermo, size(Proj_thermo,1)*size(Proj_thermo,2),size(Proj_thermo,3));   %data [Nk,Nc] Nc complex k-space data vectors
    traj_Thermo = trajtotale(:,parameter.Nspokes*(image_number-1)+1:parameter.Nspokes*(image_number),1:2);
    traj_Thermo = reshape(traj_Thermo,size(traj_Thermo,1)*size(traj_Thermo,2),2);
    traj_Thermo = traj_Thermo./(acqp.fov/size(Kspace_proj,1));

        dcf = repmat(abs(traj_Thermo(:,1)+1i*traj_Thermo(:,2)),[1 parameter.number_of_channels]);
        dcf = dcf./max(abs(dcf(:)));
        dcf = single(dcf);
        
    bucket(image_number).acqp.k  = traj_Thermo;
    bucket(image_number).acqp.dcf = dcf;
end
clearvars Proj_thermo traj_Thermo dcf;
%% Prof. William Grissom script
thetainit = single(0*acqp.mask); % initialize with zeros
thetakacc = single(zeros(size(acqp.mask,1),size(acqp.mask,2),floor(size(Kspace_proj,2)/parameter.Nspokes)));
tic
hbar = parfor_progressbar(floor(size(Kspace_proj,2)/parameter.Nspokes),'Computing...');
parfor image_number = 1:floor(size(Kspace_proj,2)/parameter.Nspokes) % parfor
    [thetakacc(:,:,image_number),~,~,~,~] = my_kspace_hybrid_thermo(bucket(image_number).acqp,L,thetainit,algp);
    hbar.iterate(1);
end
close(hbar);
parameter.processing_duration = toc;
Temp_Grissom = parameter.ct*real(thetakacc);

%% interp2D
[X,Y] = meshgrid(1:size(Temp_Grissom,1));
[Xq,Yq] = meshgrid(1:(size(Temp_Grissom,1)-1)./(size(Kspace_proj,1)-1):size(Temp_Grissom,1));
Temp_Grissom_zf = zeros(size(Kspace_proj,1),size(Kspace_proj,1),size(Temp_Grissom,3));
for ind = 1:size(Temp_Grissom,3)
    Temp_Grissom_zf(:,:,ind) = interp2(X,Y,squeeze(Temp_Grissom(:,:,ind)),Xq,Yq,'linear');
end
Temp_Grissom = Temp_Grissom_zf;