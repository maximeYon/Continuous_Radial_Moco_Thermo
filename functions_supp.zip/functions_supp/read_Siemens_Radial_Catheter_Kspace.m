function [Kspace_proj,kspace_cath,parameter] = read_Siemens_Radial_Catheter_Kspace(filename,PCAcc,varagin)

% This function Read siement radial K-space data, split the kspace between
% classical coil and catheter coils. It also perform pre-whitening and PCA
% coil compression on classical coils
% It is design to work with two input : the filename of the FID of the one
% of the noise.
% maxime Yon 06/04/2020 (confined)

if exist('varagin','var')==1
    dset_noise = ismrmrd.Dataset(varagin, 'dataset');
end
dset = ismrmrd.Dataset(filename, 'dataset');
clearvars filename;

%% Read some fields from the XML header %%
if exist('varagin','var')==1
    hdr_noise = ismrmrd.xml.deserialize(dset_noise.readxml);
end
hdr = ismrmrd.xml.deserialize(dset.readxml);

% Matrix size
parameter = struct;
parameter.Nx = hdr.encoding.encodedSpace.matrixSize.x;
parameter.Ny = hdr.encoding.encodedSpace.matrixSize.y;
parameter.Nz = hdr.encoding.encodedSpace.matrixSize.z;

% Field of View
parameter.FOVx = hdr.encoding.encodedSpace.fieldOfView_mm.x;
parameter.FOVy = hdr.encoding.encodedSpace.fieldOfView_mm.y;
parameter.FOVz = hdr.encoding.encodedSpace.fieldOfView_mm.z;

[ parameter.number_of_slices, parameter.number_of_channels , parameter.number_of_repetitions, parameter.number_of_contrasts, parameter.number_of_phase, parameter.number_of_average , parameter.number_of_segments] = get_number_of( hdr );
parameter.TR =hdr.sequenceParameters.TR; parameter.TE =hdr.sequenceParameters.TE;

coilsLabels = hdr.acquisitionSystemInformation.coilLabel;
%% Read the data
if exist('varagin','var')==1
    D_noise = dset_noise.readAcquisition();
end
D = dset.readAcquisition();
clearvars dset_noise dset;

%% Ignore noise scans and navigator scans
% TODO add a pre-whitening example
% Find the first non-noise scan
% This is how to check if a flag is set in the acquisition header
isNoise = D.head.flagIsSet('ACQ_IS_NOISE_MEASUREMENT');
firstScan = find(isNoise==0,1,'first');
if firstScan > 1
    %     noise = D.select(1:firstScan-1);
else
    noise = [];
end

isNavigator = D.head.flagIsSet('ACQ_IS_NAVIGATION_DATA');
if firstScan > 1
    isNavigator(1:firstScan) =ones(1,firstScan);
end
notNavigator = find(~ isNavigator);
notNoise = find(~ isNoise);
tracking = find( isNavigator);
is_Data = intersect(notNavigator,notNoise);
meas  = D.select(is_Data);

if size(tracking,2)>firstScan
    meas_track  = D.select(tracking);
end

clearvars D noise isNoise firstScan isNavigator notNavigator is_Data;

%% remove tracking coils from meas and isolate them in meas_cath
not_cath = ones(1,size(coilsLabels,2));
ind = 0;
for ncoil = 1:size(coilsLabels,2)
    coil_name = coilsLabels(1,ncoil).coilName;
    if contains(coil_name,'Cath')==1
        not_cath(1,ncoil)=0;
        ind = ind+1;
        parameter.cath_coil{ind} = coil_name;
    end
end

% from the noise data
if exist('varagin','var')==1
    for ind = 1:size(D_noise.data,2)
        data_tmp = D_noise.data(ind);
        data_tmp = data_tmp{1,1};
        data_tmp = data_tmp(:,logical(not_cath));
        D_noise.data(ind) = {data_tmp};
    end
end
parameter.number_of_channels = sum(not_cath);

% isolate tracking coils
kspace_cath = zeros(size(meas.data{1,1},1),size(meas.data{1,1},2)-sum(not_cath),size(meas.data,2));
for ind = 1:size(meas.data,2)
    data_tmp = meas.data(ind);
    data_tmp = data_tmp{1,1};
    data_tmp = data_tmp(:,logical(abs(not_cath-1)));
    kspace_cath(:,:,ind) = data_tmp;
end

% from the fid data
for ind = 1:size(meas.data,2)
    data_tmp = meas.data(ind);
    data_tmp = data_tmp{1,1};
    data_tmp = data_tmp(:,logical(not_cath));
    meas.data(ind) = {data_tmp};
end
hdr.acquisitionSystemInformation.receiverChannels = parameter.number_of_channels;
clearvars not_cath ncoil coil_name ind data_tmp;

%% Pre-whitening
if exist('varagin','var')==1
    acq_noise_measurement =  find( (D_noise.head.flagIsSet('ACQ_IS_NOISE_MEASUREMENT'))  ...
        & ~(D_noise.head.flagIsSet('ACQ_IS_SURFACECOILCORRECTIONSCAN_DATA')) );
    
    correc_oversampling = 1; %% NUFFT perform better with oversampling
    
    [ triangular_covariance_matrix , dmtxTotalNormalize] = my_extract_covariance_matrix( D_noise, acq_noise_measurement , parameter.number_of_channels );
    [ data_kspace ,  triangular_covariance_matrix_bw , data_before ] = my_apply_pre_whitening( meas, D_noise, hdr, triangular_covariance_matrix, correc_oversampling );
    
    clearvars hdr_noise hdr triangular_covariance_matrix dmtxTotalNormalize correc_oversampling triangular_covariance_matrix_bw acq_noise_measurement;
    clearvars D D_noise mat_white mat_white_imag mat_white_real data_before;
    
    %% create struct
    meas_white=cell(1,size(data_kspace,2));
    for p=1:size(data_kspace,2)
        meas_white{p} = squeeze(data_kspace(:,p,:));
    end
end

%% PCA coil compression
if exist('varagin','var')==1
    if strcmp(PCAcc,'true') ==1
        meas.data = coil_compression_radial(meas_white,0.1); % or meas.data   meas_white 0.1
    else
        meas.data = meas_white;
    end
    clearvars meas_white;
else
    if strcmp(PCAcc,'true') ==1
        meas.data = coil_compression_radial(meas.data,0.1); % or meas.data   meas_white
    else
        meas.data = meas.data;
    end
end
parameter.number_of_channels = size(meas.data{1,1},2);

% figure()
% data_plot = meas.data{1,9000};
% plot(abs(FFTKSpace2XSpace(data_plot,1)))

%% clear meas
Kspace_proj = zeros(size(meas.data{1},1),size(meas.data,2),parameter.number_of_channels);
for p=1:size(meas.data,2)
    Kspace_proj(:,p,:) = meas.data{p};
end
head = meas.head;
Kspace_proj = single(Kspace_proj);
clearvars meas p;