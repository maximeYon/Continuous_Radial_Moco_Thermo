function [resp] = Quantitative_frequency_filter(x,Fs,sigma)
% Quantitative gaussian frequency filter to isolate the respiration signal.
% For respiration sigma =0.32, X0 = 0;


% sigma =0.32;
X0 = 0;

freq_axis = -0.5:1/(size(x,1)-1):0.5;
freq_axis = freq_axis.*Fs;
g = 1/(sigma.*sqrt(2*pi())).*exp(-0.5*(((freq_axis-X0)/sigma).^2));
g = g./max(g);
g = repmat(g',1,size(x,2));

freq_x = FFTXSpace2KSpace(x,1);
resp = real(FFTKSpace2XSpace(freq_x.*g,1));
% Fc = 1.1774*sigma



