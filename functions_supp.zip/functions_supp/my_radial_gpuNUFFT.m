function [parameter,img_comb,img_comb_full] = my_radial_gpuNUFFT(parameter,Kspace_proj,trajtotale,DCF)
% Coil combination performed by inati or sos (1 or 0)
inati_option =1;

parameter.Nx = parameter.Nxorig;
parameter.Ny = parameter.Nyorig;

wg = 2;    sw = 4;    osf=1;
img_comb=zeros(parameter.Nx,parameter.Nx,parameter.Nimages);
img_sens=zeros(parameter.Nx,parameter.Nx,parameter.number_of_channels);

trajtotale = trajtotale./2;

for image_number = 1:parameter.Nimages
    proj_im = Kspace_proj(:,parameter.Nspokes*(image_number-1)+1:parameter.Nspokes*(image_number),:);
    proj_im = reshape(proj_im,size(proj_im,1)*size(proj_im,2),size(proj_im,3));  
    traj_NUFFT = trajtotale(:,parameter.Nspokes*(image_number-1)+1:parameter.Nspokes*(image_number),1:2);
    traj_NUFFT = reshape(traj_NUFFT,size(traj_NUFFT,1)*size(traj_NUFFT,2),2);
    DCFnufft = DCF(:,parameter.Nspokes*(image_number-1)+1:parameter.Nspokes*(image_number),:);
    DCFnufft = reshape(DCFnufft,size(DCFnufft,1)*size(DCFnufft,2),1);
    
    FT = gpuNUFFT(traj_NUFFT',DCFnufft.^2,osf,wg,sw,[parameter.Nx,parameter.Ny],[],true);
    
    %% COIL COMBINE
    for cha=1:parameter.number_of_channels
        img_sens(:,:,cha) = FT'*proj_im(:,cha);
        if inati_option ==1
            if (image_number==1)
                ccm_inati = my_Reco_Inati_ccm(img_sens, 5, 3);
            end
            img_comb(:,:,image_number) = my_Reco_Inati(img_sens,ccm_inati);
        else
            img_comb(:,:,image_number) = sos(img_sens,3,2);
        end
    end
end

%% process full image
proj_im_full = reshape(Kspace_proj,size(Kspace_proj,1)*size(Kspace_proj,2),size(Kspace_proj,3));
traj_NUFFT_full = reshape(trajtotale(:,:,1:2),size(trajtotale,1)*size(trajtotale,2),2);
DCFnufft_full = reshape(DCF,size(DCF,1)*size(DCF,2),1);
FT = gpuNUFFT(traj_NUFFT_full',DCFnufft_full.^2,osf,wg,sw,[parameter.Nx,parameter.Ny],[],true);
img_sens_full =zeros(parameter.Nx,parameter.Nx,parameter.number_of_channels);
for cha=1:parameter.number_of_channels
    img_sens_full(:,:,cha) = FT'*proj_im_full(:,cha);
    if inati_option ==1
        ccm_inati = my_Reco_Inati_ccm(img_sens_full, 5, 3);
        img_comb_full = my_Reco_Inati(img_sens_full,ccm_inati);
    else
        img_comb_full = sos(img_sens_full,3,2);
    end
end
