function [parameter,Kspace_proj_corr] = my_2D_rigid_MOCO(parameter,Resp,Kspace_proj,trajtotale)

    phase_curve_dim1 = -repmat(Resp(:,2),1,2);
    phase_curve_dim1 = reshape(permute(phase_curve_dim1,[2 1]),size(phase_curve_dim1,1)*size(phase_curve_dim1,2),1);
    phase_curve_dim2 = -repmat(Resp(:,1),1,2);
    phase_curve_dim2 = reshape(permute(phase_curve_dim2,[2 1]),size(phase_curve_dim2,1)*size(phase_curve_dim2,2),1);
    phase_curve_dim1_mean = mean(phase_curve_dim1);
    phase_curve_dim1 = phase_curve_dim1-phase_curve_dim1_mean;
    phase_curve_dim2_mean = mean(phase_curve_dim2);
    phase_curve_dim2 = phase_curve_dim2-phase_curve_dim2_mean;
    
    % Fill the phase_curve_dim in case of odd number of spoke
    if size(phase_curve_dim1,1)<size(Kspace_proj,2)
        Npoints_diff = size(Kspace_proj,2)-size(phase_curve_dim1,1);
        filling_points_dim1 = repmat(phase_curve_dim1(end,1),Npoints_diff,1);
        phase_curve_dim1 = cat(1,phase_curve_dim1,filling_points_dim1);
        filling_points_dim2 = repmat(phase_curve_dim2(end,1),Npoints_diff,1);
        phase_curve_dim2 = cat(1,phase_curve_dim2,filling_points_dim2);
    end
    
    clearvars phase_curve_dim2_mean phase_curve_dim1_mean histo bin pos_hist;
    
    direction_vector_dim1 = squeeze(trajtotale(1,:,1)-trajtotale(end,:,1));
    direction_vector_dim2 = squeeze(trajtotale(1,:,2)-trajtotale(end,:,2));
    Kspace_proj_corr = zeros(size(Kspace_proj));
    Kspace_proj_no_MOCO = Kspace_proj;
    
    % Motion correction
    readout = size(Kspace_proj,1);
    for p = 1:size(Kspace_proj,2)
        vect_dir_dim1 = (ones(readout,1)).*((((0:readout-1)/readout)')-0.5).*direction_vector_dim1(1,p);
        vect_dir_dim2 = (ones(readout,1)).*((((0:readout-1)/readout)')-0.5).*direction_vector_dim2(1,p);
        vect_phase = ones(readout,1).*(exp((1i*2*pi*phase_curve_dim1(p,1)*vect_dir_dim1)+(1i*2*pi*phase_curve_dim2(p,1)*vect_dir_dim2)));
        for c = 1:size(Kspace_proj,3)
            Kspace_proj_corr(:,p,c) = squeeze(Kspace_proj(:,p,c)).*vect_phase;
        end
    end